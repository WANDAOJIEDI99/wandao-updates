# -*- coding: utf-8 -*-
"""万道工作台 · 在线更新（GitHub 更新通道，零依赖）。

设计：
  - 源码仓（私有）   : WANDAOJIEDI99/wandao-workbench
  - 更新通道（公开） : WANDAOJIEDI99/wandao-updates
      manifest.json        版本清单（最新版本 / 补丁 / 整包信息）
      patch-<from>_<to>.zip 增量补丁（改动文件 + patch.json）
  - 国内直连 raw.githubusercontent 常被 reset，按 CANDIDATES 顺序回退镜像。

用法：
  python run/wandao_update.py check
  python run/wandao_update.py apply [--force]
  python run/wandao_update.py package        # 下载整包（壳需要重装时用）

安全：
  - 只接受 https + 白名单 host
  - 补丁与整包都校验 sha256
  - 覆盖前把受影响文件备份到 data/_update/backup-<旧版本>/
  - 只写 kernel/ modes/ skills/ docs/ config/ 下的相对路径；拒绝绝对路径与 ..
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import sys
import time
import urllib.parse
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))   # D:\WandaoHermes（HERE=kernel\run）
DATA = os.environ.get("WANDAO_HOME") or os.path.join(ROOT, "data", "_wandao")
UPDATE_DIR = os.path.join(DATA, "..", "_update") if False else os.path.join(ROOT, "data", "_update")

REPO_UPDATES = "WANDAOJIEDI99/wandao-updates"
BRANCH = "main"

ALLOWED_HOSTS = (
    "raw.githubusercontent.com",
    "cdn.jsdelivr.net",
    "ghproxy.net",
    "gh-proxy.com",
    "mirror.ghproxy.com",
)

CANDIDATES = (
    "https://raw.githubusercontent.com/{repo}/{branch}/{path}",
    "https://cdn.jsdelivr.net/gh/{repo}@{branch}/{path}",
    "https://ghproxy.net/https://raw.githubusercontent.com/{repo}/{branch}/{path}",
    "https://gh-proxy.com/https://raw.githubusercontent.com/{repo}/{branch}/{path}",
)

UA = "WandaoHermes-Updater/1.0"
LOCAL_VERSION_FILE = os.path.join(HERE, "version.json")


def _log(msg):
    print(msg, flush=True)


def local_version() -> str:
    try:
        with io.open(LOCAL_VERSION_FILE, encoding="utf-8") as f:
            return str(json.load(f).get("version") or "").strip()
    except Exception:
        return ""


def _write_local_version(ver: str, extra: dict | None = None):
    payload = {"version": ver, "updated_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    if extra:
        payload.update(extra)
    with io.open(LOCAL_VERSION_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(payload, ensure_ascii=False, indent=1) + "\n")


def _fetch(url: str, timeout: int = 30) -> bytes:
    host = urllib.parse.urlsplit(url).hostname or ""
    if not url.startswith("https://") or not any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS):
        raise ValueError("host 不在白名单: " + host)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_first(path: str, timeout: int = 30) -> tuple[bytes, str]:
    errors = []
    for tpl in CANDIDATES:
        url = tpl.format(repo=REPO_UPDATES, branch=BRANCH, path=path)
        try:
            data = _fetch(url, timeout=timeout)
            if data:
                return data, url
        except Exception as e:      # noqa: BLE001
            errors.append("%s -> %s" % (url.split("/")[2], e))
    raise RuntimeError("所有通道都失败：" + " | ".join(errors))


def get_manifest() -> tuple[dict, str]:
    raw, url = fetch_first("manifest.json")
    return json.loads(raw.decode("utf-8")), url


def check() -> dict:
    cur = local_version()
    man, url = get_manifest()
    latest = str(man.get("version") or "")
    patch = None
    if latest and cur and latest != cur:
        for p in man.get("patches", []):
            if str(p.get("from")) == cur and str(p.get("to")) == latest:
                patch = p
                break
    pkg = man.get("package") or {}
    return {
        "ok": True,
        "current": cur,
        "latest": latest,
        "has_update": bool(latest and latest != cur),
        "patch": patch,
        "shell_changed": bool(man.get("shell_changed")),
        "package": {
            "name": pkg.get("name"),
            "size": pkg.get("size"),
            "sha256": pkg.get("sha256"),
            "version": pkg.get("version"),
            "url": pkg.get("url") or (pkg.get("path") and "https://raw.githubusercontent.com/%s/%s/%s" % (REPO_UPDATES, BRANCH, pkg["path"])),
        },
        "notes": man.get("notes", ""),
        "released_at": man.get("released_at", ""),
        "manifest_url": url,
    }


def _safe_rel(rel: str) -> str:
    rel = rel.replace("\\", "/").lstrip("/")
    if not rel or rel.startswith("..") or "/../" in rel or ":" in rel:
        raise ValueError("非法路径: " + rel)
    top = rel.split("/")[0]
    if top not in ("kernel", "modes", "skills", "docs", "config"):
        raise ValueError("补丁不允许写 " + top)
    return rel


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def apply(force: bool = False) -> dict:
    info = check()
    if not info["has_update"] and not force:
        return {"ok": True, "changed": 0, "message": "已是最新版本 " + (info["current"] or "?")}
    patch = info.get("patch")
    if not patch:
        return {
            "ok": False,
            "need_package": True,
            "message": "没有从 %s 到 %s 的增量补丁，需要下载整包" % (info["current"] or "?", info["latest"]),
            "package": info["package"],
        }

    raw, url = fetch_first("patches/" + patch["file"], timeout=120)
    avail = hashlib.sha256(raw).hexdigest()
    if patch.get("sha256") and avail != patch["sha256"]:
        return {"ok": False, "message": "补丁 sha256 不匹配（期望 %s 实得 %s）" % (patch["sha256"][:12], avail[:12])}

    os.makedirs(UPDATE_DIR, exist_ok=True)
    zpath = os.path.join(UPDATE_DIR, patch["file"])
    with open(zpath, "wb") as f:
        f.write(raw)

    backup = os.path.join(UPDATE_DIR, "backup-" + (info["current"] or "unknown"))
    changed, deleted, backed = [], [], 0
    with zipfile.ZipFile(zpath) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        meta = {}
        if "patch.json" in names:
            meta = json.loads(z.read("patch.json").decode("utf-8"))
            names = [n for n in names if n != "patch.json"]
        for name in names:
            rel = _safe_rel(name)
            dst = os.path.join(ROOT, rel.replace("/", os.sep))
            if os.path.exists(dst):
                bdst = os.path.join(backup, rel.replace("/", os.sep))
                os.makedirs(os.path.dirname(bdst), exist_ok=True)
                shutil.copy2(dst, bdst)
                backed += 1
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            data = z.read(name)
            want = None
            for it in meta.get("files", []):
                if it.get("path") == rel:
                    want = it.get("sha256")
                    break
            if want and hashlib.sha256(data).hexdigest() != want:
                return {"ok": False, "message": "文件校验失败: " + rel}
            with open(dst, "wb") as f:
                f.write(data)
            changed.append(rel)
        for rel in meta.get("delete", []):
            rel = _safe_rel(rel)
            dst = os.path.join(ROOT, rel.replace("/", os.sep))
            if os.path.exists(dst):
                bdst = os.path.join(backup, rel.replace("/", os.sep))
                os.makedirs(os.path.dirname(bdst), exist_ok=True)
                shutil.copy2(dst, bdst)
                os.remove(dst)
                deleted.append(rel)

    _write_local_version(info["latest"], {"from": info["current"], "patch": patch["file"]})
    return {
        "ok": True,
        "from": info["current"],
        "to": info["latest"],
        "changed": len(changed),
        "deleted": len(deleted),
        "backup": backup if backed else "",
        "need_restart": True,
        "message": "已从 %s 更新到 %s：%d 个文件，重启后生效" % (info["current"], info["latest"], len(changed)),
    }


def download_package(dest_dir: str | None = None) -> dict:
    info = check()
    pkg = info.get("package") or {}
    url = pkg.get("url")
    if not url:
        return {"ok": False, "message": "清单里没有整包地址"}
    dest_dir = dest_dir or os.path.join(ROOT, "data", "_update")
    os.makedirs(dest_dir, exist_ok=True)
    name = pkg.get("name") or "WandaoHermes-share.7z"
    out = os.path.join(dest_dir, name)
    _log("下载整包 %s ..." % name)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=600) as r, open(out, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            got += len(chunk)
            if total and got % (64 << 20) < (1 << 20):
                _log("  %d%% (%d/%d MB)" % (got * 100 // total, got >> 20, total >> 20))
    got_sha = h.hexdigest()
    if pkg.get("sha256") and got_sha != pkg["sha256"]:
        return {"ok": False, "message": "整包 sha256 不匹配", "path": out}
    return {"ok": True, "path": out, "size": os.path.getsize(out), "sha256": got_sha,
            "message": "整包已下载到 " + out}


def main(argv):
    cmd = (argv[1] if len(argv) > 1 else "check").lower()
    if cmd == "check":
        print(json.dumps(check(), ensure_ascii=False, indent=1))
    elif cmd == "apply":
        print(json.dumps(apply(force="--force" in argv), ensure_ascii=False, indent=1))
    elif cmd == "package":
        print(json.dumps(download_package(), ensure_ascii=False, indent=1))
    elif cmd == "version":
        print(local_version() or "(未设置)")
    else:
        print("用法: wandao_update.py check|apply|package|version")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
