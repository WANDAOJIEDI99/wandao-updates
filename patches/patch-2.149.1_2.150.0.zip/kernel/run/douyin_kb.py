# -*- coding: utf-8 -*-
"""万道 · 抖音收藏采集器（走 CDP，不逆向、不签名、不碰验证码）。

## 设计取舍（为什么这么做）

- **不直连签名 API**：抖音的 `a_bogus`/`X-Bogus` 随时改，自签是长期负担。
  这里走「页面内 fetch」——用已登录页面自己的环境发请求，cookie 与签名由浏览器产生，
  这是 tars1230 / douyin-favorites-mcp 等项目验证过的同一条路。
- **独立 Chrome profile**：`D:/WandaoHermes/data/_wandao/douyin-profile`，
  不碰用户日常浏览器；扫码一次，之后复用登录态。
- **只采本人收藏**：不做他人账号、不批量、不绕验证码（合规红线）。
- **账本 + 幂等**：SQLite 存 content_sha256，作者改昵称只更新元数据，不重复下载。

## 用法

    python run/douyin_kb.py status
    python run/douyin_kb.py login            # 起浏览器等扫码（需人工扫码）
    python run/douyin_kb.py fetch --limit 20 # 采收藏（默认 20 条）
    python run/douyin_kb.py list --limit 10  # 看账本里已有的

产物：`D:/DeepSeek/抖音收藏库/<作者>/<日期>-<标题>-<id>.md`（可直接进 khoj 同步）
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import urllib.request

ROOT = os.environ.get('WANDAO_ROOT') or 'D:/WandaoHermes'
PROFILE_DIR = os.path.join(ROOT, 'data', '_wandao', 'douyin-profile')
DATA_DIR = os.path.join(ROOT, 'data', '_wandao', 'douyin')
RAW_DIR = os.path.join(DATA_DIR, 'raw')
LEDGER = os.path.join(DATA_DIR, 'ledger.db')
OUT_DIR = os.environ.get('DOUYIN_OUT') or 'D:/DeepSeek/抖音收藏库'
CDP_PORT = int(os.environ.get('DOUYIN_CDP_PORT') or 9335)

CHROME_CANDIDATES = (
    os.path.join(ROOT, 'tools', 'chromium-1208', 'chrome-win64', 'chrome.exe'),
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
)

# 真实端点（2026-11-15 用 CDP 抓 Network 确认）：
#   · 收藏：本机实测该账号收藏为空，端点未取到；
#   · 喜欢：https://www-hj.douyin.com/aweme/v1/web/aweme/favorite/  ← 域名是 www-hj，不是 www
# 之前的 listcollection 在 www.douyin.com 上已经是 404。
LIST_ENDPOINTS = (
    {'source': 'collection', 'url': 'https://www-hj.douyin.com/aweme/v1/web/aweme/listcollection/'},
    {'source': 'collection', 'url': 'https://www-hj.douyin.com/aweme/v1/web/aweme/collect/list/'},
    {'source': 'like', 'url': 'https://www-hj.douyin.com/aweme/v1/web/aweme/favorite/'},
)


# ── CDP ────────────────────────────────────────────────────────────────
def _http_json(path: str, timeout: float = 5):
    with urllib.request.urlopen(f'http://127.0.0.1:{CDP_PORT}{path}', timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8', 'replace'))


def _cdp_alive() -> bool:
    try:
        return bool(_http_json('/json/version').get('Browser'))
    except Exception:  # noqa: BLE001
        return False


def _chrome_path() -> str:
    for path in CHROME_CANDIDATES:
        if os.path.isfile(path):
            return path
    return ''


def launch_chrome(url: str = 'https://www.douyin.com/') -> dict:
    if _cdp_alive():
        return {'ok': True, 'already_running': True, 'port': CDP_PORT}
    chrome = _chrome_path()
    if not chrome:
        return {'ok': False, 'error': 'NO_CHROME', 'tried': list(CHROME_CANDIDATES)}
    os.makedirs(PROFILE_DIR, exist_ok=True)
    args = [
        chrome,
        f'--user-data-dir={PROFILE_DIR}',
        f'--remote-debugging-port={CDP_PORT}',
        '--no-first-run',
        '--no-default-browser-check',
        url,
    ]
    proc = subprocess.Popen(args, close_fds=True)
    # 不阻塞等待 Chrome 退出（GUI 进程长期存活），直接进入轮询
    for i in range(30):
        time.sleep(1)
        if proc.poll() is not None:
            proc.wait(timeout=5)
            return {'ok': False, 'error': f'CHROME_EXITED_CODE_{proc.returncode}', 'port': CDP_PORT}
        if _cdp_alive():
            return {'ok': True, 'port': CDP_PORT, 'profile': PROFILE_DIR}
    proc.kill()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    return {'ok': False, 'error': 'CDP_NOT_READY', 'port': CDP_PORT}


async def _cdp_call(method: str, params: dict | None = None, timeout: float = 30):
    """在页面 target 上发一条 CDP 命令并返回 result（用于 Network/Storage 这类非 evaluate 调用）。"""
    import websockets

    targets = await asyncio.to_thread(_http_json, '/json')
    page = next((t for t in targets if t.get('type') == 'page'), None)
    if not page:
        raise RuntimeError('没有可用的页面')

    async with websockets.connect(page['webSocketDebuggerUrl'], max_size=64 * 1024 * 1024) as ws:
        await ws.send(json.dumps({'id': 1, 'method': method, 'params': params or {}}))
        while True:
            message = json.loads(await ws.recv())
            if message.get('id') == 1:
                if 'error' in message:
                    raise RuntimeError(str(message['error'])[:300])
                return message.get('result') or {}


def _cookies_sync() -> dict:
    """拿当前浏览器的 douyin cookie（Network.getAllCookies 能读到 httpOnly 的 sessionid）。"""
    try:
        result = asyncio.run(_cdp_call('Network.getAllCookies'))
    except Exception as exc:  # noqa: BLE001
        return {'ok': False, 'error': str(exc)[:200]}
    cookies = result.get('cookies') or []
    douyin = [c for c in cookies if 'douyin.com' in str(c.get('domain', ''))]
    names = {c.get('name') for c in douyin}
    return {
        'ok': True,
        'douyin_cookie_count': len(douyin),
        'has_sessionid': 'sessionid' in names,
        'has_sessionid_ss': 'sessionid_ss' in names,
        'has_uid_tt': bool(names & {'uid_tt', 'uid_tt_ss'}),
        'names_sample': sorted(n for n in names if n)[:12],
    }


async def _cdp_eval(expression: str, timeout: float = 60, await_promise: bool = True):
    """在页面里执行一段 JS，返回其值（自动取第一个 page target）。"""
    import websockets

    targets = await asyncio.to_thread(_http_json, '/json')
    page = next((t for t in targets if t.get('type') == 'page'), None)
    if not page:
        raise RuntimeError('没有可用的页面（浏览器没开或全是后台页）')

    async with websockets.connect(page['webSocketDebuggerUrl'], max_size=64 * 1024 * 1024) as ws:
        await ws.send(json.dumps({'id': 1, 'method': 'Runtime.enable', 'params': {}}))
        await ws.recv()
        payload = {
            'id': 2,
            'method': 'Runtime.evaluate',
            'params': {
                'expression': expression,
                'returnByValue': True,
                'awaitPromise': await_promise,
                'timeout': int(timeout * 1000),
            },
        }
        await ws.send(json.dumps(payload))
        while True:
            message = json.loads(await ws.recv())
            if message.get('id') == 2:
                if 'exceptionDetails' in message.get('result', {}):
                    detail = message['result']['exceptionDetails']
                    raise RuntimeError(str(detail.get('exception', {}).get('description') or detail)[:400])
                return message.get('result', {}).get('result', {}).get('value')


LOGIN_PROBE_JS = r"""
(() => {
  const cookieHas = (name) => document.cookie.split(';').some(p => p.trim().startsWith(name + '='))
  const t = document.title || ''
  return JSON.stringify({
    url: location.href,
    title: t,
    hasSessionCookie: cookieHas('sessionid') || cookieHas('sessionid_ss'),
    loggedInHint: !/登录/.test(t) && !document.querySelector('.login-mask, [class*="login-modal"]'),
    hasQr: !!document.querySelector('[class*="qrcode"], canvas, [class*="qrcode-img"]'),
  })
})()
"""


def cmd_status(args) -> int:
    alive = _cdp_alive()
    state = {'cdp': alive, 'port': CDP_PORT, 'profile': PROFILE_DIR, 'chrome': _chrome_path() or None}
    if alive:
        state['cookies'] = _cookies_sync()
        try:
            state['page'] = json.loads(asyncio.run(_cdp_eval(LOGIN_PROBE_JS, timeout=15)))
        except Exception as exc:  # noqa: BLE001
            state['page_error'] = str(exc)[:200]
    state['ledger'] = _ledger_stats()
    print(json.dumps(state, ensure_ascii=False, indent=1))
    return 0


def cmd_login(args) -> int:
    launched = launch_chrome('https://www.douyin.com/')
    print(json.dumps(launched, ensure_ascii=False))
    if not launched.get('ok'):
        return 2
    deadline = time.time() + args.wait
    while time.time() < deadline:
        try:
            probe = json.loads(asyncio.run(_cdp_eval(LOGIN_PROBE_JS, timeout=20)))
        except Exception as exc:  # noqa: BLE001
            print(json.dumps({'phase': 'probe_error', 'error': str(exc)[:200]}, ensure_ascii=False))
            time.sleep(3)
            continue
        cookies = _cookies_sync()
        phase = {'phase': 'waiting', 'probe': probe, 'cookies': cookies}
        print(json.dumps(phase, ensure_ascii=False))
        if cookies.get('ok') and (cookies.get('has_sessionid') or cookies.get('has_sessionid_ss')):
            print(json.dumps({'ok': True, 'logged_in': True, 'cookies': cookies}, ensure_ascii=False))
            return 0
        if probe.get('hasSessionCookie'):
            print(json.dumps({'ok': True, 'logged_in': True, 'probe': probe}, ensure_ascii=False))
            return 0
        time.sleep(3)
    print(json.dumps({'ok': False, 'error': 'LOGIN_TIMEOUT', 'wait_s': args.wait,
                      'hint': '在弹窗里扫码（抖音 APP → 扫一扫），扫完保持页面不动'}, ensure_ascii=False))
    return 3


# ── 采集 ───────────────────────────────────────────────────────────────
def _fetch_js(endpoint: str, limit: int) -> str:
    return r"""
(async () => {
  const endpoint = %s
  const max = %d
  const out = []
  const errors = []
  let cursor = 0
  let hasMore = true
  let page = 0
  while (out.length < max && hasMore && page < 10) {
    const url = endpoint + '?device_platform=webapp&aid=6383&channel=channel_pc_web&count=20&cursor=' + cursor
    let resp
    try {
      resp = await fetch(url, {
        credentials: 'include',
        headers: { 'referer': 'https://www.douyin.com/user/self?showTab=favorite_collection' },
      })
    } catch (e) { errors.push('fetch_failed: ' + String(e)); break }
    if (!resp.ok) { errors.push('http_' + resp.status); break }
    let data
    try { data = await resp.json() } catch (e) { errors.push('not_json'); break }
    const list = data.aweme_list || data.collects || data.data || []
    if (!Array.isArray(list) || !list.length) { errors.push('empty_list'); break }
    out.push(...list)
    hasMore = Boolean(data.has_more)
    cursor = Number(data.cursor || (cursor + 20))
    page += 1
    await new Promise(r => setTimeout(r, 800))
  }
  return JSON.stringify({ items: out.slice(0, max), errors, pages: page, endpoint })
})()
""" % (json.dumps(endpoint), limit)


def _pick_first(item: dict) -> dict:
    """把 aweme 结构压成万道要的字段（结构随版本变，能取到就取）。"""
    desc = str(item.get('desc') or item.get('title') or '').strip()
    author = (item.get('author') or {}).get('nickname') or (item.get('author') or {}).get('unique_id') or '未知作者'
    aweme_id = str(item.get('aweme_id') or item.get('awemeId') or item.get('id') or '')
    stats = item.get('statistics') or {}
    video = item.get('video') or {}
    play = (video.get('play_addr') or {}).get('url_list') or []
    cover = ((video.get('cover') or {}).get('url_list') or [None])[0]
    return {
        'aweme_id': aweme_id,
        'desc': desc,
        'author': author,
        'url': f'https://www.douyin.com/video/{aweme_id}' if aweme_id else '',
        'play_url': play[0] if play else '',
        'cover': cover,
        'digg': stats.get('digg_count'),
        'comment': stats.get('comment_count'),
        'create_time': item.get('create_time'),
    }


def _ledger() -> sqlite3.Connection:
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(LEDGER)
    conn.execute(
        'CREATE TABLE IF NOT EXISTS items ('
        'aweme_id TEXT PRIMARY KEY, title TEXT, author TEXT, url TEXT, '
        'media_path TEXT, md_path TEXT, content_sha TEXT, updated_at REAL)'
    )
    conn.commit()
    return conn


def _ledger_stats() -> dict:
    if not os.path.isfile(LEDGER):
        return {'exists': False, 'count': 0}
    try:
        conn = sqlite3.connect(LEDGER)
        count = conn.execute('SELECT COUNT(*) FROM items').fetchone()[0]
        latest = conn.execute('SELECT MAX(updated_at) FROM items').fetchone()[0]
        conn.close()
        return {'exists': True, 'count': count, 'latest': latest}
    except Exception as exc:  # noqa: BLE001
        return {'exists': True, 'error': str(exc)[:120]}


def _safe_name(text: str, limit: int = 40) -> str:
    cleaned = re.sub(r'[\\/:*?"<>|\r\n\t]+', '_', text).strip(' ._')
    return (cleaned or 'untitled')[:limit]


def cmd_fetch(args) -> int:
    if not _cdp_alive():
        print(json.dumps({'ok': False, 'error': 'CDP_DOWN', 'hint': '先 python run/douyin_kb.py login'}, ensure_ascii=False))
        return 2

    endpoint_used = ''
    source_used = ''
    data = None
    errors = []
    wanted = (args.source or 'auto').lower()
    for cand in LIST_ENDPOINTS:
        if wanted != 'auto' and cand['source'] != wanted:
            continue
        endpoint = cand['url']
        try:
            raw = asyncio.run(_cdp_eval(_fetch_js(endpoint, args.limit), timeout=args.timeout))
            parsed = json.loads(raw) if isinstance(raw, str) else raw
        except Exception as exc:  # noqa: BLE001
            errors.append({'endpoint': endpoint, 'error': str(exc)[:200]})
            continue
        if parsed.get('items'):
            data = parsed
            endpoint_used = endpoint
            source_used = cand['source']
            break
        errors.append({'endpoint': endpoint, 'empty': True, 'inner': parsed.get('errors')})

    if not data or not data.get('items'):
        print(json.dumps({'ok': False, 'error': 'NO_ITEMS', 'tried': errors,
                          'hint': '确认已登录且收藏夹非空；也可能是端点改名（把新端点加进 LIST_ENDPOINTS）'},
                         ensure_ascii=False, indent=1))
        return 4

    os.makedirs(RAW_DIR, exist_ok=True)
    conn = _ledger()
    saved = []
    skipped = 0
    for item in data['items']:
        picked = _pick_first(item)
        if not picked['aweme_id']:
            continue
        with open(os.path.join(RAW_DIR, picked['aweme_id'] + '.json'), 'w', encoding='utf-8') as fh:
            json.dump(item, fh, ensure_ascii=False)

        sha = hashlib.sha256((picked['desc'] + picked['author']).encode('utf-8')).hexdigest()
        row = conn.execute('SELECT content_sha FROM items WHERE aweme_id = ?', (picked['aweme_id'],)).fetchone()
        if row and row[0] == sha:
            skipped += 1
            continue

        day = time.strftime('%Y%m%d', time.localtime(picked['create_time'] or time.time()))
        md_dir = os.path.join(OUT_DIR, _safe_name(picked['author'], 24))
        os.makedirs(md_dir, exist_ok=True)
        md_path = os.path.join(md_dir, f"{day}-{_safe_name(picked['desc'] or picked['aweme_id'], 40)}-{picked['aweme_id']}.md")
        body = [
            '---',
            f"platform: douyin",
            f"aweme_id: {picked['aweme_id']}",
            f"author: {picked['author']}",
            f"url: {picked['url']}",
            f"collected_at: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"digg: {picked['digg']}",
            f"cover: {picked['cover']}",
            '---',
            '',
            f"# {picked['desc'] or '(无标题)'}",
            '',
            f"- 作者：{picked['author']}",
            f"- 链接：{picked['url']}",
            '',
            '## 原始描述',
            '',
            picked['desc'] or '(空)',
            '',
        ]
        with open(md_path, 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(body))
        conn.execute(
            'INSERT INTO items (aweme_id,title,author,url,media_path,md_path,content_sha,updated_at) '
            'VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(aweme_id) DO UPDATE SET '
            'title=excluded.title, author=excluded.author, url=excluded.url, md_path=excluded.md_path, '
            'content_sha=excluded.content_sha, updated_at=excluded.updated_at',
            (picked['aweme_id'], picked['desc'], picked['author'], picked['url'], '',
             md_path, sha, time.time())
        )
        saved.append({'aweme_id': picked['aweme_id'], 'title': picked['desc'][:40], 'author': picked['author'], 'md': md_path})
    conn.commit()
    conn.close()

    print(json.dumps({
        'ok': True,
        'source': source_used,
        'endpoint': endpoint_used,
        'fetched': len(data['items']),
        'saved': len(saved),
        'skipped_same': skipped,
        'pages': data.get('pages'),
        'out_dir': OUT_DIR,
        'ledger': _ledger_stats(),
        'sample': saved[:5],
        'errors': data.get('errors'),
    }, ensure_ascii=False, indent=1))
    return 0


def cmd_list(args) -> int:
    if not os.path.isfile(LEDGER):
        print(json.dumps({'ok': True, 'items': [], 'note': '账本还没建立（先 fetch）'}, ensure_ascii=False))
        return 0
    conn = sqlite3.connect(LEDGER)
    rows = conn.execute('SELECT aweme_id,title,author,md_path,updated_at FROM items ORDER BY updated_at DESC LIMIT ?',
                        (args.limit,)).fetchall()
    conn.close()
    print(json.dumps({'ok': True, 'stats': _ledger_stats(),
                      'items': [{'id': r[0], 'title': r[1], 'author': r[2], 'md': r[3]} for r in rows]},
                     ensure_ascii=False, indent=1))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description='抖音收藏采集器（CDP，只采本人收藏）')
    sub = ap.add_subparsers(dest='cmd', required=True)

    sub.add_parser('status').set_defaults(func=cmd_status)

    lg = sub.add_parser('login')
    lg.add_argument('--wait', type=int, default=180)
    lg.set_defaults(func=cmd_login)

    ft = sub.add_parser('fetch')
    ft.add_argument('--limit', type=int, default=20)
    ft.add_argument('--source', default='auto', choices=['auto', 'collection', 'like'])
    ft.add_argument('--timeout', type=int, default=120)
    ft.set_defaults(func=cmd_fetch)

    ls = sub.add_parser('list')
    ls.add_argument('--limit', type=int, default=10)
    ls.set_defaults(func=cmd_list)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
