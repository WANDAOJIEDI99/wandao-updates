# -*- coding: utf-8 -*-
"""万道工作台 · 现代 Web 规范检索（modern-web-guidance 内核工具）。

## 为什么要有这一层

模型写前端时会按训练数据里的老写法生成（自造 modal、`::-webkit-scrollbar`、
`document.write`、`XMLHttpRequest`）。GoogleChrome/modern-web-guidance 把 209 篇
「现代写法」指南做成了可检索的包，但官方 CLI 走 `npx -y ...@latest`：
不锁版本 + 每次从 npm 拉最新，属于供应链风险面，也不能离线。

所以这里直接吃技能包自带的 `guides/**/*.md`，检索脚本是技能里的
`scripts/mwg.py`（纯标准库、零网络）。本模块只做：定位脚本 → 调它 → 把 JSON
转成工具结果。**不重复实现检索逻辑**，避免两份代码漂移。

## 三处登记（缺一处就静默失效）

1. `tools_builtin.py` 末尾的 `for _mod in (...)` —— 真正让它被 import 注册；
2. `tool_registry.py` 的 `CONTEXT_TOOLSETS` —— toolset 用现成的 `web`，已在集合里，
   模型才看得见；
3. `permission.py` 的 `default_gate()` —— 默认 ASK，只读动作要显式 allow。
"""
from __future__ import annotations

import json
import json
import os
import subprocess
import sys
import tempfile

from tool_registry import tool, tool_error

_GUIDE_CANDIDATES = (
    os.path.join(os.environ.get('DSH_HOME') or os.path.join(os.path.expanduser('~'), '.dsh'),
                 'skills', 'modern-web-guidance'),
    os.path.join(os.environ.get('HERMES_HOME') or '', 'skills', 'web', 'modern-web-guidance'),
    'D:/AgentHarness-WandaoHermes/WandaoHermes-data/skills/web/modern-web-guidance',
    'D:/WandaoHermes/data/home/skills/web/modern-web-guidance',
)

_TIMEOUT_S = 60
_MAX_RETRIEVE_CHARS = 12000


def _mwg_script() -> str:
    """找到技能里的检索脚本；找不到就返回空串（调用方如实报错）。"""
    for base in _GUIDE_CANDIDATES:
        if not base:
            continue
        script = os.path.join(base, 'scripts', 'mwg.py')
        if os.path.isfile(script):
            return script
    return ''


def _run(*args: str) -> tuple[int, str, str]:
    script = _mwg_script()
    if not script:
        return 127, '', ('没找到 modern-web-guidance 技能包。请确认 '
                         '`~/.dsh/skills/modern-web-guidance/scripts/mwg.py` 或 '
                         '`<HERMES_HOME>/skills/web/modern-web-guidance/scripts/mwg.py` 存在。')
    try:
        try:
            done = subprocess.run(
                [sys.executable, '-X', 'utf8', script, *args],
                capture_output=True,
                encoding='utf-8',
                errors='replace',
                text=True,
                timeout=_TIMEOUT_S,
            )
        except subprocess.TimeoutExpired:
            return 124, '', f'检索脚本超时（>{_TIMEOUT_S}s）'
    except Exception as exc:  # noqa: BLE001
        return 1, '', f'检索脚本启动失败：{exc}'
    return done.returncode, done.stdout or '', done.stderr or ''


@tool(name='mwg_search', toolset='web', timeout=_TIMEOUT_S,
      description='查现代 Web 写法（209 篇离线指南，来自 Google Chrome 团队）。'
                  '写或改前端界面（弹窗/表格/表单/滚动条/暗色/无障碍/性能/动画）之前先搜一次，'
                  '别按训练数据里的老写法写。返回 id + 摘要，命中后用 mwg_retrieve 取全文。')
def mwg_search(query: str, limit: int = 5) -> str:
    """检索现代 Web 规范指南。

    query: 2–5 个词，描述单个能力或 UI 模式（如 "light dismiss dialog"），
           别带框架名（React/Vue）与业务名词
    limit: 返回条数，1-10，默认 5
    """
    query = (query or '').strip()
    if not query:
        return tool_error('BAD_ARGS', 'query 不能为空')
    limit = max(1, min(10, int(limit or 5)))
    code, out, err = _run('search', query, '-n', str(limit))
    if code != 0:
        return tool_error('MWG_FAILED', (err or out or f'rc={code}').strip()[:600])
    try:
        hits = json.loads(out)
    except Exception:  # noqa: BLE001
        return out.strip()[:4000] or '（没有结果）'
    if not hits:
        return json.dumps({'hits': [], 'note': '没有匹配的指南；换一个更具体的控件名再搜一次，仍没有就说明这套指南没覆盖。'},
                          ensure_ascii=False)
    return json.dumps({'hits': hits, 'next': '用 mwg_retrieve(ids=命中的 id，逗号分隔) 取全文'}, ensure_ascii=False)


@tool(name='mwg_retrieve', toolset='web', timeout=_TIMEOUT_S,
      description='按 id 取现代 Web 指南全文（可逗号分隔多个）。只在 mwg_search 命中后调用，'
                  '别整目录读——全量约 47 万 token。')
def mwg_retrieve(ids: str) -> str:
    """取指南全文。

    ids: 一个或多个指南 id，逗号分隔（如 "light-dismiss-a-dialog,dialog"）
    """
    ids = (ids or '').strip()
    if not ids:
        return tool_error('BAD_ARGS', 'ids 不能为空')
    code, out, err = _run('retrieve', ids)
    if code != 0 and not out.strip():
        return tool_error('MWG_FAILED', (err or f'rc={code}').strip()[:600])
    text = out
    if len(text) > _MAX_RETRIEVE_CHARS:
        try:
            handle, path = tempfile.mkstemp(prefix='mwg-', suffix='.md')
            with os.fdopen(handle, 'w', encoding='utf-8') as fh:
                fh.write(text)
            head = text[:_MAX_RETRIEVE_CHARS]
            return head + f'\n\n…（已截断，全文 {len(text)} 字符，落在 {path}，需要时用文件工具读）'
        except Exception:  # noqa: BLE001
            return text[:_MAX_RETRIEVE_CHARS] + '\n\n…（已截断）'
    return text or '（没有内容）'


@tool(name='mwg_lint', toolset='web', timeout=_TIMEOUT_S,
      description='对前端目录/文件做简版老写法扫描（约 10 条高确定性规则：::-webkit-scrollbar、'
                  'document.write、内联 onclick、缺 alt、自造 modal、XMLHttpRequest）。'
                  '注意：这不是官方 legacy-scan，0 命中不等于代码现代。')
def mwg_lint(path: str, limit: int = 30) -> str:
    """扫描前端目录里的老写法。

    path: 目录或单个文件（.html/.css/.js/.ts/.tsx/.vue/.svelte）
    limit: 最多返回多少条命中，默认 30
    """
    path = (path or '').strip()
    if not path:
        return tool_error('BAD_ARGS', 'path 不能为空')
    if not os.path.exists(path):
        return tool_error('NOT_FOUND', f'路径不存在：{path}')
    limit = max(1, min(200, int(limit or 30)))
def mwg_lint_data(path: str, limit: int = 200) -> dict:
    """与 mwg_lint 同一条扫描，但返回 **dict**（不截断）。

    为什么单独一个：mwg_lint 给模型看，会截到 20000 字；面板要吃完整 JSON，
    截断后前端解析失败会把整坨 JSON 当错误显示出来（用户看到的就是一片红字）。
    """
    path = (path or '').strip()
    if not path:
        return {'error': 'path 不能为空'}
    if not os.path.exists(path):
        return {'error': '路径不存在：' + path}
    limit = max(1, min(500, int(limit or 200)))
    code, out, err = _run('lint', path, '--limit', str(limit))
    if code != 0:
        return {'error': (err or out or ('rc=%d' % code)).strip()[:600]}
    try:
        data = json.loads(out)
    except Exception as exc:  # noqa: BLE001
        return {'error': '扫描器输出不是合法 JSON：' + str(exc)[:120]}
    if isinstance(data, dict):
        data['findings'] = (data.get('findings') or [])[:limit]
    return data


    code, out, err = _run('lint', path, '--limit', str(limit))
    if code != 0:
        return tool_error('MWG_FAILED', (err or out or f'rc={code}').strip()[:600])
    return out.strip()[:20000] or '（没有输出）'
